package com.example.cdp_canworks;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.net.Uri;

import androidx.appcompat.app.AppCompatActivity;

public class manager_Main extends AppCompatActivity {

    ImageView emblem; // 매장이미지
    TextView storeName;  // 매장이름
    TextView storeNum;   // 매장번호
    TextView storeCode;  // 매장고유번호

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.manager_main);

        Intent intent = getIntent();
        String number = intent.getExtras().getString("storeNumber");

        emblem = (ImageView)findViewById(R.id.emblem);
        storeName = (TextView)findViewById(R.id.storeName);
        storeNum  = (TextView)findViewById(R.id.storeNum);

        final DBHelper helper = new DBHelper(getApplicationContext(), "canworks.db", null, 1);
        Cursor cursor = helper.getStoreInfo(number);

        String[] items = new String[30];

        while(cursor.moveToNext()) {
            storeNum.setText(cursor.getString(1));
            storeName.setText(cursor.getString(2));
            emblem.setImageURI(Uri.parse("file://"+cursor.getString(8)));
        }


        ListAdapter adapter = new manager_ImageAdapter(this,items);
        ListView listView = (ListView)findViewById(R.id.Listview);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(
                new AdapterView.OnItemClickListener(){
                    @Override
                    public void onItemClick(AdapterView<?>parent, View view, int i, long id){
                        String item=String.valueOf(parent.getItemAtPosition(i));
                        Toast.makeText(manager_Main.this, item, Toast.LENGTH_SHORT).show();
                    }
                }
        );
    }
}
